export const BASE_URL = 'https://api.gravityphysics.online';

