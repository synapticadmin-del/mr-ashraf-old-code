import AsyncStorage from '@react-native-async-storage/async-storage';
import { createApi } from '@reduxjs/toolkit/query/react';
import { Platform } from 'react-native';
import { BASE_URL } from '@/constants/config';
import { tokenStorage } from '@/utils/tokenStorage';

/**
 * طبقة الـAPI مُعاد بناؤها على باكند Gravity (api.gravityphysics.online).
 * الشاشات تتوقع غلاف `{ success, data, message }` — كل transform هنا
 * يطبع ردود Gravity على هذا الشكل حتى لا تُلمس الشاشات.
 */

// ─── أنواع مشتركة (الشكل الذي تتوقعه الشاشات) ───

export interface EducationalStage {
  id: string;
  nameAr: string;
  nameEn?: string;
}

export interface EducationalMaterial {
  id: string;
  nameAr: string;
  nameEn?: string;
  description?: string;
  image?: string | null;
}

export interface Exam {
  id: string;
  title: string;
  description?: string;
  duration?: number;
  price?: number;
  isPaid?: boolean;
  questions?: any[];
  totalPoints?: number;
  image?: string | null;
  startTime?: string | null;
  endTime?: string | null;
  canAccess?: boolean;
  accessLabel?: string;
  actionLabel?: string;
  categoryLabel?: string;
  courseTitle?: string;
  studentScore?: number | null;
  isSubmitted?: boolean;
  isCustom?: boolean;
}

export interface ExamResult {
  score: number;
  totalScore: number;
  totalPoints: number;
  maxScore?: number;
  percentage: number;
  passed?: boolean;
  answers: Array<{
    questionIndex?: number;
    questionId?: string;
    question?: string;
    isCorrect: boolean;
    selected?: string | null;
    selectedAnswer?: number;
    correct?: string | null;
    correctAnswer?: number | null;
    correctAnswerReason?: string | null;
    options?: string[];
    explanation?: string | null;
  }>;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  description?: string;
  features: string[];
  courses?: any[];
}

export interface PaymentWallet {
  id: string;
  name: string;
  phone: string;
  sortOrder?: number;
  isActive?: boolean;
}

export interface NewsItemApi {
  id: string;
  title: string;
  content?: string;
  published: boolean;
  imageUrl?: string | null;
  sortOrder?: number;
}

export interface CommonExamMistake {
  id: string;
  title: string;
  content?: string;
  description?: string;
  subject?: string;
  imageUrl?: string | null;
  order: number;
  published: boolean;
}

export interface ChallengeQuestionItem {
  id: string;
  question: string;
  question_text: string;
  image_url?: string | null;
  options: string[];
  points: number;
  sort_order?: number;
}

export interface StudentMistake {
  id: string;
  examTitle: string;
  submittedAt: string;
  points: number;
  questionIndex: number;
  question: string;
  options: string[];
  selectedAnswer: number;
  correctAnswer: number;
  isResolved?: boolean;
}

export interface BuiltExam {
  id: string;
  title: string;
  description?: string;
  duration_minutes: number;
  question_count: number;
  price: number;
  status: string;
  status_label?: string;
  created_at?: string;
}

// ─── أدوات مساعدة ───

const DEVICE_ID_KEY = '@gravity_device_id';
let cachedDeviceId: string | null = null;

async function getDeviceId(): Promise<string> {
  if (cachedDeviceId) return cachedDeviceId;
  try {
    const existing = await AsyncStorage.getItem(DEVICE_ID_KEY);
    if (existing) {
      cachedDeviceId = existing;
      return existing;
    }
    const id = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    await AsyncStorage.setItem(DEVICE_ID_KEY, id);
    cachedDeviceId = id;
    return id;
  } catch {
    return 'unknown-device';
  }
}

const EXPO_PLATFORM = Platform.OS === 'ios' ? 'ios' : 'android';

async function authHeaders(json = true): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'X-Platform': EXPO_PLATFORM,
    'X-Device-Id': await getDeviceId(),
    'X-App-Version': '1.0.0',
    'X-Requested-With': 'XMLHttpRequest',
  };
  if (json) headers['Content-Type'] = 'application/json';
  const token = await tokenStorage.getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

/** fetch محمّل بهيدرز Gravity — يُستخدم داخل queryFn للمسارات المركّبة. */
async function apiFetch(path: string, init: RequestInit = {}) {
  const isJson = typeof init.body === 'string';
  const hdrs = await authHeaders(isJson);
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { ...hdrs, ...(init.headers as Record<string, string> | undefined) },
  });
  const text = await res.text();
  let body: any = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = null;
  }
  if (!res.ok) {
    const message = body?.error?.message || body?.message || `HTTP ${res.status}`;
    const err: any = new Error(message);
    err.status = res.status;
    err.data = body?.error || body;
    throw err;
  }
  return body;
}

/** يرفع صورة من uri محلية إلى /uploads/proof ويعيد رابطها. */
async function uploadProofImage(uri: string): Promise<string> {
  const filename = uri.split('/').pop() || 'proof.jpg';
  const ext = (filename.match(/\.(\w+)$/)?.[1] || 'jpg').toLowerCase();
  const contentType = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
  const imageRes = await fetch(uri);
  const blob = await imageRes.blob();
  const headers = await authHeaders(false);
  headers['Content-Type'] = contentType;
  const res = await fetch(`${BASE_URL}/uploads/proof`, {
    method: 'POST',
    headers,
    body: blob,
  });
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.url) {
    throw new Error(body?.error?.message || 'فشل رفع صورة إثبات التحويل');
  }
  return body.url as string;
}

/** يحوّل صف الطالب من Gravity لشكل StudentData القديم. */
function normalizeStudent(profile: any, points?: any) {
  if (!profile) return profile;
  return {
    id: profile.id,
    name: profile.full_name,
    email: profile.email,
    phone: profile.phone,
    username: profile.full_name,
    phoneNumber: profile.phone,
    image: profile.avatar_url,
    birthday: '',
    studentCode: profile.student_code,
    educationalStageId: profile.grade,
    grade: profile.grade,
    branch: profile.branch,
    role: profile.role,
    level: points?.level ?? profile.level ?? 1,
    totalPoints: points?.total_points ?? profile.points ?? 0,
    createdAt: profile.created_at,
    updatedAt: profile.updated_at,
    card_verified: profile.card_verified,
    stats: {
      currentPlan: undefined,
      numberOfExams: 0,
      totalPoints: points?.total_points ?? 0,
    },
  };
}

function mapCourseToMaterial(course: any): EducationalMaterial {
  return {
    id: course.id,
    nameAr: course.title || course.name,
    nameEn: course.title_en,
    description: course.description,
    image: course.cover_image || course.image_url,
  };
}

function mapGravityExam(q: any): Exam {
  const price = q.price ?? 0;
  const isPaid = !(q.is_free === 1 || q.is_free === true || price === 0);
  return {
    id: q.id,
    title: q.title,
    description: q.description || q.course_title || '',
    duration: q.time_limit_mins ?? q.duration ?? 0,
    price,
    isPaid,
    totalPoints: q.max_score ?? q.total_points,
    image: q.cover_image || null,
    startTime: q.start_time ?? null,
    endTime: q.end_time ?? null,
    canAccess: q.can_access,
    accessLabel: q.access_label,
    actionLabel: q.action_label,
    categoryLabel: q.category_label,
    courseTitle: q.course_title,
    studentScore: q.student_score ?? null,
    isSubmitted: q.is_submitted === 1 || q.is_submitted === true,
    isCustom: q.is_custom === 1 || q.is_custom === true,
    questions: q.questions ?? [],
  };
}

function mapChallengeRow(row: any): ChallengeQuestionItem {
  return {
    id: row.id,
    question: row.question_text,
    question_text: row.question_text,
    image_url: row.image_url ?? null,
    options: row.options ?? [],
    points: row.points ?? 1,
    sort_order: row.sort_order,
  };
}

const TAB_KEY_MAP: Record<string, string> = {
  conversations: 'chats',
  common_mistakes: 'common-mistakes',
};

// ─── الـSlice ───

interface ApiEnvelope<T> {
  success: boolean;
  data: T;
  message?: string;
  token?: string;
}

export const apiSlice = createApi({
  reducerPath: 'api',
  baseQuery: async (args: { url: string; method?: string; body?: unknown }) => {
    try {
      const data = await apiFetch(args.url, {
        method: args.method || 'GET',
        body: args.body !== undefined ? JSON.stringify(args.body) : undefined,
      });
      return { data };
    } catch (e: any) {
      return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message, ...(e.data || {}) } } };
    }
  },
  tagTypes: [
    'Student', 'Students', 'Materials', 'SubMaterials', 'Chapters', 'Exams',
    'Purchases', 'Mistakes', 'CommonMistakes', 'News', 'Wallets', 'Plans',
    'Challenges', 'ChallengeRequests', 'BuiltExams', 'TabsConfig', 'Parent',
  ],
  endpoints: (builder) => ({
    // ── المصادقة ──
    studentLogin: builder.mutation<ApiEnvelope<any>, { code: string; password: string }>({
      async queryFn(arg) {
        try {
          const identifier = arg.code.trim();
          const body: Record<string, string> = identifier.includes('@')
            ? { email: identifier, password: arg.password }
            : { phone: identifier, password: arg.password };
          const res = await apiFetch('/auth/login', { method: 'POST', body: JSON.stringify(body) });
          const student = normalizeStudent(res.user);
          return {
            data: {
              success: true,
              token: res.access_token,
              message: 'تم تسجيل الدخول بنجاح',
              data: { token: res.access_token, refresh_token: res.refresh_token, student },
            },
          };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
    }),

    parentLogin: builder.mutation<ApiEnvelope<any>, { code: string; password: string }>({
      async queryFn(arg) {
        try {
          const identifier = arg.code.trim();
          const body: Record<string, string> = identifier.includes('@')
            ? { email: identifier, password: arg.password }
            : { phone: identifier, password: arg.password };
          const res = await apiFetch('/auth/login', { method: 'POST', body: JSON.stringify(body) });
          // وليّ الأمر: نجلب أول طالب مرتبط حتى تفتح صفحته مباشرة.
          let student: any = null;
          try {
            const children = await apiFetch('/parent/children');
            const first = (children?.children || [])[0];
            if (first) {
              student = normalizeStudent({ ...first, student_code: first.student_code });
            }
          } catch {
            // حساب غير مرتبط بأبناء — يكمل بدون studentId.
          }
          return {
            data: {
              success: true,
              token: res.access_token,
              message: 'تم تسجيل الدخول بنجاح',
              data: {
                token: res.access_token,
                refresh_token: res.refresh_token,
                student,
                parent: normalizeStudent(res.user),
              },
            },
          };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
    }),

    getStudent: builder.query<ApiEnvelope<any>, string>({
      async queryFn(studentId) {
        try {
          // إن لم يكن الطالب نفسه → ملخص ولي الأمر
          const meRes = await apiFetch('/auth/me');
          const me = meRes?.user ?? meRes;
          const isSelf = !studentId || studentId === 'me' || studentId === me?.id;
          if (!isSelf) {
            const summary = await apiFetch(`/parent/children/${encodeURIComponent(studentId)}/summary`);
            const s = summary?.student || summary?.child || summary;
            return { data: { success: true, data: normalizeStudent(s) } };
          }
          let points: any = null;
          try {
            points = await apiFetch('/me/points');
          } catch {
            points = null;
          }
          return { data: { success: true, data: normalizeStudent(me, points) } };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      providesTags: ['Student'],
    }),

    // ── إعدادات الواجهة ──
    getTabsConfig: builder.query<ApiEnvelope<{ tabs: any[] }>, void>({
      query: () => ({ url: '/tabs-config' }),
      transformResponse: (res: any) => ({
        success: true,
        data: {
          tabs: (res?.tabs ?? []).map((t: any) => ({
            key: TAB_KEY_MAP[t.key] ?? t.key,
            titleAr: t.label ?? t.titleAr ?? t.key,
            icon: t.icon,
            isVisible: t.isVisible ?? true,
            order: t.order ?? 99,
          })),
        },
      }),
      providesTags: ['TabsConfig'],
    }),

    // ── المحتوى ──
    getEducationalMaterials: builder.query<ApiEnvelope<EducationalMaterial[]>, void>({
      query: () => ({ url: '/courses' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.courses ?? res?.materials ?? []).map(mapCourseToMaterial),
      }),
      providesTags: ['Materials'],
    }),

    getEducationalMaterial: builder.query<ApiEnvelope<EducationalMaterial>, string>({
      query: (id) => ({ url: `/courses/${encodeURIComponent(id)}` }),
      transformResponse: (res: any) => ({
        success: true,
        data: mapCourseToMaterial(res?.course ?? res),
      }),
      providesTags: ['Materials'],
    }),

    getSubMaterials: builder.query<ApiEnvelope<any[]>, void>({
      query: () => ({ url: '/exam-builds/sections' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.sections ?? []).map((s: any) => ({
          id: s.id,
          nameAr: s.title,
          questionCount: s.question_count,
        })),
      }),
      providesTags: ['SubMaterials'],
    }),

    getChaptersBySubMaterialIds: builder.query<ApiEnvelope<any[]>, string[]>({
      query: (ids) => ({ url: `/exam-builds/chapters?section_ids=${(ids || []).join(',')}` }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.chapters ?? []).map((ch: any) => ({
          id: ch.id,
          nameAr: ch.title,
          courseId: ch.course_id,
          questionCount: ch.question_count,
        })),
      }),
      providesTags: ['Chapters'],
    }),

    // ── الامتحانات ──
    getExamsByEducationalMaterialId: builder.query<ApiEnvelope<Exam[]>, string>({
      query: () => ({ url: '/courses/exams' }),
      transformResponse: (res: any, _meta, courseId) => ({
        success: true,
        data: (res?.exams ?? [])
          .filter((q: any) => String(q.course_id) === String(courseId))
          .map(mapGravityExam),
      }),
      providesTags: ['Exams'],
    }),

    getExamById: builder.query<ApiEnvelope<Exam>, string>({
      query: (id) => ({ url: `/courses/exams/${id}` }),
      transformResponse: (res: any) => {
        const e = res?.exam ?? {};
        const qs = (res?.questions ?? []).map((q: any) => ({
          id: q.id,
          question: q.question_text,
          question_text: q.question_text,
          image_url: q.image_url ?? null,
          options: q.options ?? [],
          score: q.score ?? 1,
          sort_order: q.sort_order,
        }));
        const exam = mapGravityExam(e);
        exam.questions = qs;
        exam.duration = e.time_limit_mins ?? exam.duration ?? 0;
        exam.totalPoints = qs.reduce((s: number, q: any) => s + (q.score || 1), 0) || e.max_score;
        return { success: true, data: exam };
      },
      providesTags: ['Exams'],
    }),

    getApprovedExams: builder.query<ApiEnvelope<any[]>, string>({
      query: () => ({ url: '/purchases' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.purchases ?? res?.requests ?? [])
          .filter((p: any) => p.status === 'approved' || p.status === 'pending')
          .map((p: any) => ({
            examId: p.exam_id,
            courseId: p.course_id,
            bundleId: p.bundle_id,
            status: p.status,
            targetType: p.target_type,
          })),
      }),
      providesTags: ['Purchases'],
    }),

    getStudentFreeExams: builder.query<ApiEnvelope<Exam[]>, string>({
      query: () => ({ url: '/courses/exams' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.exams ?? [])
          .filter((q: any) => q.is_free === 1 || q.is_free === true || !q.price || q.price === 0)
          .map(mapGravityExam),
      }),
      providesTags: ['Exams'],
    }),

    getStudentPaidExams: builder.query<ApiEnvelope<Exam[]>, string>({
      query: () => ({ url: '/courses/exams' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.exams ?? [])
          .filter((q: any) => q.price > 0 && q.category_label !== 'باقة' && !(q.category_label || '').includes('باقة'))
          .map(mapGravityExam),
      }),
      providesTags: ['Exams'],
    }),

    getStudentPlanExams: builder.query<ApiEnvelope<Exam[]>, string>({
      query: () => ({ url: '/courses/exams' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.exams ?? [])
          .filter((q: any) => (q.category_label || '').includes('باقة'))
          .map(mapGravityExam),
      }),
      providesTags: ['Exams'],
    }),

    getStudentBuiltExams: builder.query<ApiEnvelope<BuiltExam[]>, string>({
      query: () => ({ url: '/exam-builds' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.exam_builds ?? res?.requests ?? res?.builds ?? []).map((b: any) => ({
          id: b.id,
          title: b.title,
          description: b.description,
          duration_minutes: b.duration_minutes,
          question_count: b.question_count,
          price: b.price,
          status: b.status,
          status_label: b.status_label,
          created_at: b.created_at,
        })),
      }),
      providesTags: ['BuiltExams'],
    }),

    buyExam: builder.mutation<ApiEnvelope<any>, { examId: string; studentId?: string; address?: string; transferScreenshot?: string } | FormData>({
      async queryFn(arg) {
        try {
          // دعم FormData القديم وكائن JSON
          let examId: string | undefined;
          let screenshot: string | undefined;
          if (typeof FormData !== 'undefined' && arg instanceof FormData) {
            const parts: any[] = (arg as any).getParts?.() ?? (arg as any)._parts ?? [];
            for (const [k, v] of parts) {
              if (k === 'examId') examId = String(v);
              if (k === 'transferScreenshot') screenshot = (v as any)?.uri ?? String(v);
            }
          } else {
            const a = arg as any;
            examId = a.examId;
            screenshot = a.transferScreenshot;
          }
          if (!examId) throw new Error('لم يتم تحديد الامتحان');
          if (!screenshot) throw new Error('يرجى رفع صورة إثبات التحويل');
          const imageUrl = await uploadProofImage(screenshot);
          const res = await apiFetch('/purchases', {
            method: 'POST',
            body: JSON.stringify({ target_type: 'exam', exam_id: examId, transfer_image_url: imageUrl }),
          });
          return { data: { success: true, message: res?.message || 'تم شراء الامتحان بنجاح', data: res } };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      invalidatesTags: ['Purchases', 'Exams'],
    }),

    solveExam: builder.mutation<ApiEnvelope<{ result: ExamResult }>, { examId: string; body: { answers: number[] } }>({
      async queryFn({ examId, body }) {
        try {
          const examRes = await apiFetch(`/courses/exams/${encodeURIComponent(examId)}`);
          const questions: any[] = examRes?.questions ?? [];
          const answers: Record<string, string> = {};
          (body.answers ?? []).forEach((optIndex, qi) => {
            const q = questions[qi];
            if (!q || optIndex == null || optIndex < 0) return;
            const opts: string[] = q.options ?? [];
            if (opts[optIndex] !== undefined) answers[q.id] = String(opts[optIndex]);
          });
          const res = await apiFetch(`/courses/exams/${encodeURIComponent(examId)}/submit`, {
            method: 'POST',
            body: JSON.stringify({ answers }),
          });
          const graded: any[] = res?.answers ?? res?.graded ?? [];
          const maxScore = res?.max_score ?? res?.total_score ?? 0;
          const earned = res?.score ?? res?.earned_score ?? 0;
          const result: ExamResult = {
            score: earned,
            totalScore: maxScore,
            totalPoints: maxScore,
            maxScore,
            percentage: maxScore > 0 ? Math.round((earned / maxScore) * 100) : (res?.percentage ?? 0),
            passed: res?.passed,
            answers: graded.map((g: any, gi: number) => {
              const q = questions.find((qq: any) => String(qq.id) === String(g.question_id ?? g.id)) ?? questions[gi];
              const opts: string[] = q?.options ?? g.options ?? [];
              const correctText = g.correct_option_text ?? g.correct ?? null;
              const sel = g.selected ?? g.given_answer ?? null;
              const idxOf = (val: any) => (val != null ? opts.findIndex((o: string) => String(o) === String(val)) : -1);
              return {
                questionIndex: gi,
                questionId: g.question_id ?? g.id,
                question: g.question_text ?? q?.question_text,
                isCorrect: g.is_correct === 1 || g.is_correct === true,
                selected: sel,
                selectedAnswer: idxOf(sel),
                correct: correctText,
                correctAnswer: correctText != null ? idxOf(correctText) : -1,
                correctAnswerReason: g.correct_answer_reason ?? g.explanation ?? null,
                options: opts,
                explanation: g.explanation ?? null,
              };
            }),
          };
          return { data: { success: true, message: 'تم إرسال الإجابات بنجاح', data: { result } } };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      invalidatesTags: ['Exams', 'Mistakes'],
    }),

    // ── أخطائي والأخطاء الشائعة ──
    getStudentMistakes: builder.query<ApiEnvelope<StudentMistake[]>, string>({
      query: () => ({ url: '/me/mistakes' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.mistakes ?? []).map((m: any, idx: number) => {
          const options: string[] = Array.isArray(m.options)
            ? m.options
            : m.options_json
              ? JSON.parse(m.options_json)
              : [];
          const findIdx = (val: any) => {
            if (typeof val === 'number') return val;
            const i = options.findIndex((o: string) => String(o) === String(val));
            return i >= 0 ? i : 0;
          };
          return {
            id: m.id,
            examTitle: m.exam_title || m.quiz_title || 'امتحان',
            submittedAt: m.created_at,
            points: m.points_lost ?? 0,
            questionIndex: idx,
            question: m.question_text,
            options,
            selectedAnswer: findIdx(m.given_answer),
            correctAnswer: findIdx(m.correct_answer),
            isResolved: m.is_resolved === 1,
          };
        }),
      }),
      providesTags: ['Mistakes'],
    }),

    getCommonExamMistakes: builder.query<ApiEnvelope<CommonExamMistake[]>, void>({
      query: () => ({ url: '/common-mistakes' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.common_mistakes ?? res?.mistakes ?? res?.items ?? []).map((m: any, i: number) => ({
          id: m.id,
          title: m.title,
          content: m.content || m.description,
          description: m.description || m.content,
          subject: m.subject ?? m.course_title ?? '',
          imageUrl: m.image_url ?? null,
          order: m.sort_order ?? m.order ?? i,
          published: m.published === 1 || m.published === true || m.published == null,
        })),
      }),
      providesTags: ['CommonMistakes'],
    }),

    // ── الأخبار ──
    getNews: builder.query<ApiEnvelope<NewsItemApi[]>, void>({
      query: () => ({ url: '/news' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.news ?? []).map((n: any) => ({
          id: n.id,
          title: n.title,
          content: n.body || n.content,
          imageUrl: n.image_url ?? null,
          published: true,
          sortOrder: n.sort_order,
        })),
      }),
      providesTags: ['News'],
    }),

    // ── محافظ الدفع والباقات ──
    getPaymentWallets: builder.query<ApiEnvelope<PaymentWallet[]>, void>({
      query: () => ({ url: '/payment-wallets' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.payment_wallets ?? []).map((w: any) => ({
          id: w.id,
          name: w.name,
          phone: w.phone,
          sortOrder: w.sort_order,
          isActive: w.is_active !== 0 && w.is_active !== false,
        })),
      }),
      providesTags: ['Wallets'],
    }),

    getPlans: builder.query<ApiEnvelope<Plan[]>, void>({
      query: () => ({ url: '/bundles' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.bundles ?? []).map((b: any) => ({
          id: b.id,
          name: b.title || b.name,
          price: b.price ?? 0,
          description: b.description,
          features: b.features ?? (b.courses || []).map((c: any) => c.title || c.name).filter(Boolean),
          courses: b.courses ?? [],
        })),
      }),
      providesTags: ['Plans'],
    }),

    requestPlanPurchase: builder.mutation<ApiEnvelope<any>, { planId?: string; bundleId?: string; transferScreenshot?: string } | FormData>({
      async queryFn(arg) {
        try {
          let bundleId: string | undefined;
          let screenshot: string | undefined;
          if (typeof FormData !== 'undefined' && arg instanceof FormData) {
            const parts: any[] = (arg as any).getParts?.() ?? (arg as any)._parts ?? [];
            for (const [k, v] of parts) {
              if (k === 'planId' || k === 'bundleId') bundleId = String(v);
              if (k === 'transferScreenshot') screenshot = (v as any)?.uri ?? String(v);
            }
          } else {
            const a = arg as any;
            bundleId = a.bundleId ?? a.planId;
            screenshot = a.transferScreenshot;
          }
          if (!bundleId) throw new Error('لم يتم تحديد الباقة');
          if (!screenshot) throw new Error('يرجى رفع صورة إثبات التحويل');
          const imageUrl = await uploadProofImage(screenshot);
          const res = await apiFetch('/purchases', {
            method: 'POST',
            body: JSON.stringify({ target_type: 'bundle', bundle_id: bundleId, transfer_image_url: imageUrl }),
          });
          return { data: { success: true, message: res?.message || 'تم إرسال طلب الاشتراك بنجاح', data: res } };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      invalidatesTags: ['Purchases', 'Plans'],
    }),

    // ── ابني امتحانك ──
    buildExamRequest: builder.mutation<ApiEnvelope<any>, {
      title: string;
      description?: string;
      durationMinutes?: number;
      questionCount: number;
      sectionIds: string[];
      chapterIds?: string[];
    } | FormData>({
      async queryFn(arg) {
        try {
          let payload: Record<string, unknown> = {};
          if (typeof FormData !== 'undefined' && arg instanceof FormData) {
            const parts: any[] = (arg as any).getParts?.() ?? (arg as any)._parts ?? [];
            const map: Record<string, any> = {};
            for (const [k, v] of parts) map[k] = v;
            payload = {
              title: map.title,
              description: map.description,
              duration_minutes: Number(map.duration ?? map.durationMinutes ?? 30),
              question_count: Number(map.questionCount ?? map.question_count ?? 10),
              section_ids: map.subMaterialIds ? JSON.parse(String(map.subMaterialIds)) : (map.sectionIds ?? map.section_ids),
              chapter_ids: map.chapterIds ? JSON.parse(String(map.chapterIds)) : (map.chapter_ids ?? undefined),
            };
          } else {
            const a = arg as any;
            payload = {
              title: a.title,
              description: a.description,
              duration_minutes: a.durationMinutes ?? a.duration_minutes ?? a.duration ?? 30,
              question_count: a.questionCount ?? a.question_count,
              section_ids: a.sectionIds ?? a.section_ids ?? a.subMaterialIds,
              chapter_ids: a.chapterIds ?? a.chapter_ids ?? undefined,
            };
          }
          const res = await apiFetch('/exam-builds', { method: 'POST', body: JSON.stringify(payload) });
          return { data: { success: true, message: res?.message || 'طلب إنشاء الامتحان مُرسل', data: res } };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      invalidatesTags: ['BuiltExams'],
    }),

    // ── تحدي الأصدقاء ──
    getStudents: builder.query<ApiEnvelope<any[]>, void>({
      query: () => ({ url: '/challenges/leaderboard' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.leaderboard ?? []).map((s: any) => ({
          id: s.student_id ?? s.id,
          name: s.full_name,
          username: s.full_name,
          image: s.avatar_url,
          level: s.level ?? 1,
          totalPoints: s.points ?? 0,
          rank: s.rank,
          badge: s.badge,
          isMe: s.is_me,
        })),
      }),
      providesTags: ['Students'],
    }),

    getIncomingChallengeRequests: builder.query<ApiEnvelope<any[]>, void>({
      query: () => ({ url: '/challenges/incoming' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.incoming ?? []).map((r: any) => ({
          id: r.id,
          challengeId: r.id,
          fromStudentId: r.challenger_id,
          fromStudentName: r.challenger_name,
          fromStudentImage: r.challenger_avatar,
          toStudentName: '',
          status: r.status,
          createdAt: r.created_at,
          durationMinutes: r.duration_minutes,
          questionCount: r.question_count,
          level: r.challenger_level,
          points: r.challenger_points,
          badge: r.badge,
          acceptLabel: r.accept_label,
          rejectLabel: r.reject_label,
        })),
      }),
      providesTags: ['ChallengeRequests'],
    }),

    getOutgoingChallengeRequests: builder.query<ApiEnvelope<any[]>, void>({
      query: () => ({ url: '/challenges/outgoing' }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.outgoing ?? []).map((r: any) => ({
          id: r.id,
          challengeId: r.id,
          toStudentId: r.opponent_id,
          toStudentName: r.opponent_name,
          toStudentImage: r.opponent_avatar,
          status: r.status,
          createdAt: r.created_at,
          durationMinutes: r.duration_minutes,
          questionCount: r.question_count,
          level: r.opponent_level,
          points: r.opponent_points,
          badge: r.badge,
        })),
      }),
      providesTags: ['ChallengeRequests'],
    }),

    sendChallengeRequest: builder.mutation<ApiEnvelope<any>, { toStudentId: string; questionCount?: number }>({
      query: ({ toStudentId, questionCount }) => ({
        url: '/challenges',
        method: 'POST',
        body: { opponent_id: toStudentId, question_count: questionCount ?? 5 },
      }),
      transformResponse: (res: any) => ({ success: true, message: 'تم إرسال التحدي', data: res }),
      invalidatesTags: ['ChallengeRequests'],
    }),

    acceptChallengeRequest: builder.mutation<ApiEnvelope<any>, string>({
      query: (challengeId) => ({ url: `/challenges/${encodeURIComponent(challengeId)}/accept`, method: 'POST' }),
      transformResponse: (res: any) => ({
        success: true,
        message: 'تم قبول التحدي',
        data: res,
      }),
      invalidatesTags: ['ChallengeRequests', 'Challenges'],
    }),

    rejectChallengeRequest: builder.mutation<ApiEnvelope<any>, string>({
      query: (challengeId) => ({ url: `/challenges/${encodeURIComponent(challengeId)}/reject`, method: 'POST' }),
      transformResponse: (res: any) => ({ success: true, message: 'تم رفض التحدي', data: res }),
      invalidatesTags: ['ChallengeRequests'],
    }),

    getChallenge: builder.query<ApiEnvelope<any>, string>({
      query: (id) => ({ url: `/challenges/${encodeURIComponent(id)}` }),
      transformResponse: (res: any) => ({
        success: true,
        data: res?.challenge ?? res,
      }),
      providesTags: ['Challenges'],
    }),

    getChallengeQuestions: builder.query<ApiEnvelope<ChallengeQuestionItem[]>, string>({
      query: (id) => ({ url: `/challenges/${encodeURIComponent(id)}` }),
      transformResponse: (res: any) => ({
        success: true,
        data: (res?.questions ?? []).map(mapChallengeRow),
      }),
      providesTags: ['Challenges'],
    }),

    submitChallenge: builder.mutation<ApiEnvelope<{ myResult: any; opponentResult: any | null }>, { challengeId: string; body: { answers: number[] } }>({
      async queryFn({ challengeId, body }) {
        try {
          const detail = await apiFetch(`/challenges/${encodeURIComponent(challengeId)}`);
          const questions: any[] = detail?.questions ?? [];
          const answers: Record<string, string> = {};
          (body.answers ?? []).forEach((optIndex, qi) => {
            const q = questions[qi];
            if (!q) return;
            const opts: string[] = q.options ?? [];
            if (optIndex >= 0 && opts[optIndex] !== undefined) answers[q.id] = String(opts[optIndex]);
          });
          const res = await apiFetch(`/challenges/${encodeURIComponent(challengeId)}/submit`, {
            method: 'POST',
            body: JSON.stringify({ answers }),
          });
          const totalPoints = questions.reduce((s: number, q: any) => s + (q.points ?? 1), 0);
          let opponentResult: any = null;
          try {
            const result = await apiFetch(`/challenges/${encodeURIComponent(challengeId)}/result`);
            const opp = result?.opponent ?? result?.opponent_result ?? null;
            if (opp) {
              opponentResult = { score: opp.score ?? 0, totalPoints };
            }
          } catch {
            opponentResult = null;
          }
          return {
            data: {
              success: true,
              data: {
                myResult: { score: res?.score ?? 0, totalPoints },
                opponentResult,
              },
            },
          };
        } catch (e: any) {
          return { error: { status: e.status ?? 'FETCH_ERROR', data: { message: e.message } } };
        }
      },
      invalidatesTags: ['Challenges', 'ChallengeRequests'],
    }),
  }),
});

export const {
  useStudentLoginMutation,
  useParentLoginMutation,
  useGetStudentQuery,
  useGetTabsConfigQuery,
  useGetEducationalMaterialsQuery,
  useGetEducationalMaterialQuery,
  useGetSubMaterialsQuery,
  useGetChaptersBySubMaterialIdsQuery,
  useGetExamsByEducationalMaterialIdQuery,
  useGetExamByIdQuery,
  useGetApprovedExamsQuery,
  useGetStudentFreeExamsQuery,
  useGetStudentPaidExamsQuery,
  useGetStudentPlanExamsQuery,
  useGetStudentBuiltExamsQuery,
  useBuyExamMutation,
  useSolveExamMutation,
  useGetStudentMistakesQuery,
  useGetCommonExamMistakesQuery,
  useGetNewsQuery,
  useGetPaymentWalletsQuery,
  useGetPlansQuery,
  useRequestPlanPurchaseMutation,
  useBuildExamRequestMutation,
  useGetStudentsQuery,
  useGetIncomingChallengeRequestsQuery,
  useGetOutgoingChallengeRequestsQuery,
  useSendChallengeRequestMutation,
  useAcceptChallengeRequestMutation,
  useRejectChallengeRequestMutation,
  useGetChallengeQuery,
  useGetChallengeQuestionsQuery,
  useSubmitChallengeMutation,
} = apiSlice;
